package org.signify;
import java.util.*;

public class SalesReport {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the total number of products:");
        int numProducts = scanner.nextInt();
        double totalSales = 0;
        double highestSales = 0;
        String highestSellingProduct = "";

        for (int i = 1; i <= numProducts; i++) {
            System.out.println("Enter the sales data for product " + i + ":");
            double sales = scanner.nextDouble();

            // Error handling for invalid input
            if (sales < 0) {
                System.out.println("Error: Sales cannot be negative. Please enter a valid number.");
                i--; // decrement i to repeat the current iteration
                continue;
            }
            totalSales += sales;
            if (sales > highestSales) {
                highestSales = sales;
                highestSellingProduct = "Product " + i;
            }
        }
        double averageSales = totalSales / numProducts;
        System.out.println("Total Sales: " + totalSales);
        System.out.println("Average Sales: " + averageSales);
        System.out.println("Highest-Selling Product: " + highestSellingProduct);
    }
}