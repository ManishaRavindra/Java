package org.day2;
public class Employee {

    private String name;
    private int age;
    private String employeeId;

    public Employee(String name, int age, String employeeId) {
        this.name = name;
        this.age = age;
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public static void main(String[] args) {
FullTimeEmployee ft =new FullTimeEmployee("Manisha",21,"PO101",71000);
double  ftSalary = ft.calculateSalary();
PartTimeEmployee pt = new PartTimeEmployee("Amrutha",32,"PO103",9,8);
double ptSalary = pt.calculateSalary();
ContractEmployee ct = new ContractEmployee("Amrutha",32,"PO102",23,120);
double ctSalary = ct.calculateSalary();
        System.out.println("The Salary of FullTimeEmployee: "+ft.calculateSalary());
        System.out.println("The Salary of FullTimeEmployee: "+pt.calculateSalary());
        System.out.println("The Salary of FullTimeEmployee: "+ct.calculateSalary());
    }
}
