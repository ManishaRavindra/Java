package org.day2;

public class FullTimeEmployee extends Employee {
    private double basicSalary;

    public FullTimeEmployee(String name, int age, String employeeId, double basicSalary) {
        super(name, age, employeeId);
        this.basicSalary = basicSalary;
    }

    public double calculateSalary() {
        double hra = 0.5 * basicSalary;
        double da = 0.2 * basicSalary;
        return basicSalary + hra + da;
    }
}
