package org.day2;


    public class ContractEmployee extends Employee {
        private double monthlyRate;
        private int contractDuration;

        public ContractEmployee(String name, int age, String employeeId, double monthlyRate, int contractDuration) {
            super(name, age, employeeId);
            this.monthlyRate = monthlyRate;
            this.contractDuration = contractDuration;
        }

        public double calculateSalary() {
            return monthlyRate * contractDuration;
        }
}
